var restify = require('restify');
var server = restify.createServer();

function respond(req, res, next) {
    res.send('hello ' + req.params.name);
    next();
}
server.get('/hello/:name', respond);
server.head('/hello/:name', respond);

server.listen(80, function() {
    console.log('%s listening at %s', server.name, server.url);
});

var restifySwaggerJsdoc = require('restify-swagger-jsdoc');
restifySwaggerJsdoc.createSwaggerPage({
    title: 'API documentation', // Page title
    version: '1.0.0', // Server version
    server: server, // Restify server instance created with restify.createServer()
    path: '/doc' // Public url where the swagger page will be available
});
